// Run AFTER `flutter create --platforms=android,ios .`
// Usage:  dart run tool/setup.dart
//
// Patches Android/iOS config: permissions, minSdk 23, removes default test.
import 'dart:io';

void main() {
  _patchManifest();
  _patchGradle();
  _patchInfoPlist();
  final t = File('test/widget_test.dart');
  if (t.existsSync()) {
    t.deleteSync();
    stdout.writeln('Removed default test/widget_test.dart');
  }
  stdout.writeln('\nTayyor! Endi: flutter pub get && flutter run');
}

void _patchManifest() {
  final f = File('android/app/src/main/AndroidManifest.xml');
  if (!f.existsSync()) {
    stdout.writeln('! AndroidManifest.xml topilmadi (android/ yo\'q?)');
    return;
  }
  var s = f.readAsStringSync();
  const perms = [
    'android.permission.RECORD_AUDIO',
    'android.permission.VIBRATE',
    'android.permission.WAKE_LOCK',
  ];
  final missing = perms.where((p) => !s.contains(p)).toList();
  if (missing.isEmpty) {
    stdout.writeln('AndroidManifest: ruxsatlar allaqachon bor');
    return;
  }
  final add = missing
      .map((p) => '    <uses-permission android:name="$p" />\n')
      .join();
  s = s.replaceFirst('<application', '$add    <application');
  f.writeAsStringSync(s);
  stdout.writeln('AndroidManifest: ${missing.length} ta ruxsat qo\'shildi');
}

void _patchGradle() {
  for (final name in ['android/app/build.gradle.kts', 'android/app/build.gradle']) {
    final f = File(name);
    if (!f.existsSync()) continue;
    var s = f.readAsStringSync();
    final before = s;
    s = s.replaceAll('minSdk = flutter.minSdkVersion', 'minSdk = 23');
    s = s.replaceAll('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 23');
    if (s != before) {
      f.writeAsStringSync(s);
      stdout.writeln('$name: minSdk = 23 qilindi');
    } else {
      stdout.writeln('$name: minSdk o\'zgarmadi (tekshiring: kamida 23 bo\'lsin)');
    }
    return;
  }
  stdout.writeln('! build.gradle topilmadi');
}

void _patchInfoPlist() {
  final f = File('ios/Runner/Info.plist');
  if (!f.existsSync()) return;
  var s = f.readAsStringSync();
  if (s.contains('NSMicrophoneUsageDescription')) return;
  s = s.replaceFirst(
    '<dict>',
    '<dict>\n\t<key>NSMicrophoneUsageDescription</key>\n'
        '\t<string>Microphone access is used to monitor sleep sounds.</string>',
  );
  f.writeAsStringSync(s);
  stdout.writeln('Info.plist: mikrofon izohi qo\'shildi');
}
