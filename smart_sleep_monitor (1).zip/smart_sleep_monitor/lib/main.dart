import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:record/record.dart';
import 'package:vibration/vibration.dart';
import 'package:wakelock_plus/wakelock_plus.dart';

void main() => runApp(const SmartSleepMonitorApp());

enum AppLanguage { uz, ru, en }

class SmartSleepMonitorApp extends StatelessWidget {
  const SmartSleepMonitorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Smart Sleep Monitor',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF536DFE)),
        useMaterial3: true,
      ),
      home: const MonitorHomePage(),
    );
  }
}

class MonitorHomePage extends StatefulWidget {
  const MonitorHomePage({super.key});

  @override
  State<MonitorHomePage> createState() => _MonitorHomePageState();
}

class _MonitorHomePageState extends State<MonitorHomePage> {
  static const Duration _windowLength = Duration(milliseconds: 700);
  static const Duration _alertCooldown = Duration(seconds: 3);

  final AudioRecorder _recorder = AudioRecorder();
  StreamSubscription<Uint8List>? _audioSubscription;
  Timer? _clockTimer;

  AppLanguage _language = AppLanguage.uz;
  bool _monitoring = false;
  bool _alertEnabled = true;
  double _thresholdDb = -25; // Prototype threshold; calibrate per device/room.
  double _currentDb = -90;
  int _events = 0;
  DateTime? _startedAt;
  DateTime? _lastAlertAt;
  String? _statusKey; // null => ready
  String? _errorText;

  // Accumulators for the current measurement window.
  double _sumSquares = 0;
  int _sampleCount = 0;
  final Stopwatch _window = Stopwatch();

  String tr(String uz, String ru, String en) {
    switch (_language) {
      case AppLanguage.uz:
        return uz;
      case AppLanguage.ru:
        return ru;
      case AppLanguage.en:
        return en;
    }
  }

  String get _status {
    if (_errorText != null) return _errorText!;
    switch (_statusKey) {
      case 'noPermission':
        return tr('Mikrofon ruxsati kerak', 'Нужно разрешение на микрофон',
            'Microphone permission is required');
      case 'active':
        return tr('Kuzatuv faol', 'Мониторинг включён', 'Monitoring active');
      case 'loud':
        return tr(
          'Baland tovush aniqlandi (xurrak bo‘lishi mumkin)',
          'Обнаружен громкий звук (возможно, храп)',
          'Loud sound detected (possible snore)',
        );
      case 'stopped':
        return tr('Kuzatuv to‘xtatildi', 'Мониторинг остановлен', 'Monitoring stopped');
      default:
        return tr('Tayyor', 'Готово', 'Ready');
    }
  }

  Future<void> _startMonitoring() async {
    final hasPermission = await _recorder.hasPermission();
    if (!hasPermission) {
      if (mounted) {
        setState(() {
          _errorText = null;
          _statusKey = 'noPermission';
        });
      }
      return;
    }

    try {
      final stream = await _recorder.startStream(
        const RecordConfig(
          encoder: AudioEncoder.pcm16bits,
          sampleRate: 16000,
          numChannels: 1,
        ),
      );

      _sumSquares = 0;
      _sampleCount = 0;
      _window
        ..reset()
        ..start();
      _lastAlertAt = null;
      _events = 0;
      _startedAt = DateTime.now();
      _audioSubscription = stream.listen(
        _onAudioChunk,
        onError: (Object e) {
          if (mounted) setState(() => _errorText = 'Xatolik: $e');
        },
      );

      // Refresh the elapsed-time label every second.
      _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
        if (mounted) setState(() {});
      });

      // Keep the screen on so Android does not suspend the microphone.
      try {
        await WakelockPlus.enable();
      } catch (_) {}

      if (mounted) {
        setState(() {
          _monitoring = true;
          _errorText = null;
          _statusKey = 'active';
        });
      }
    } catch (e) {
      if (mounted) setState(() => _errorText = 'Xatolik: $e');
    }
  }

  /// Computes loudness (dBFS) from raw PCM16 little-endian samples.
  void _onAudioChunk(Uint8List bytes) {
    if (!_monitoring) return;

    final samples = bytes.lengthInBytes ~/ 2;
    if (samples > 0) {
      final data = ByteData.sublistView(bytes);
      for (var i = 0; i < samples; i++) {
        final s = data.getInt16(i * 2, Endian.little).toDouble();
        _sumSquares += s * s;
      }
      _sampleCount += samples;
    }

    if (_window.elapsed >= _windowLength && _sampleCount > 0) {
      final rms = math.sqrt(_sumSquares / _sampleCount);
      final db = rms <= 0 ? -90.0 : 20 * math.log(rms / 32768) / math.ln10;
      _sumSquares = 0;
      _sampleCount = 0;
      _window
        ..reset()
        ..start();
      _handleLevel(db.clamp(-90.0, 0.0).toDouble());
    }
  }

  // IMPORTANT: Loudness is not snore classification. This is a simple demo
  // trigger only. Replace it with a trained audio model for real use.
  Future<void> _handleLevel(double db) async {
    if (!mounted) return;
    final now = DateTime.now();
    final loud = db >= _thresholdDb;
    final coolingDown = _lastAlertAt != null &&
        now.difference(_lastAlertAt!) < _alertCooldown;

    if (!loud || !_alertEnabled || coolingDown) {
      setState(() => _currentDb = db);
      return;
    }

    _lastAlertAt = now;
    setState(() {
      _currentDb = db;
      _events += 1;
      _statusKey = 'loud';
    });

    try {
      if (await Vibration.hasVibrator() == true) {
        await Vibration.vibrate(duration: 450);
      }
      await SystemSound.play(SystemSoundType.alert);
    } catch (_) {
      // Alerts are best-effort; never crash monitoring because of them.
    }
  }

  Future<void> _stopMonitoring() async {
    _clockTimer?.cancel();
    _clockTimer = null;
    await _audioSubscription?.cancel();
    _audioSubscription = null;
    try {
      if (await _recorder.isRecording()) await _recorder.stop();
    } catch (_) {}
    try {
      await WakelockPlus.disable();
    } catch (_) {}
    if (mounted) {
      setState(() {
        _monitoring = false;
        _currentDb = -90;
        _statusKey = 'stopped';
      });
    }
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _audioSubscription?.cancel();
    WakelockPlus.disable();
    _recorder.dispose();
    super.dispose();
  }

  String _elapsedText() {
    if (_startedAt == null) return '—';
    final d = DateTime.now().difference(_startedAt!);
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inHours)}:${two(d.inMinutes % 60)}:${two(d.inSeconds % 60)}';
  }

  @override
  Widget build(BuildContext context) {
    final levelFraction = ((_currentDb + 90) / 90).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Sleep Monitor'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: DropdownButton<AppLanguage>(
              value: _language,
              underline: const SizedBox.shrink(),
              onChanged: (value) {
                if (value != null) setState(() => _language = value);
              },
              items: const [
                DropdownMenuItem(value: AppLanguage.uz, child: Text('UZ')),
                DropdownMenuItem(value: AppLanguage.ru, child: Text('RU')),
                DropdownMenuItem(value: AppLanguage.en, child: Text('EN')),
              ],
            ),
          ),
        ],
      ),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600),
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      Icon(
                        _monitoring ? Icons.nights_stay : Icons.bedtime_outlined,
                        size: 64,
                        color: Theme.of(context).colorScheme.primary,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _monitoring
                            ? tr('Uyqu kuzatilmoqda', 'Сон отслеживается', 'Sleep monitoring')
                            : tr('Uyqu kuzatuvi', 'Мониторинг сна', 'Sleep monitor'),
                        style: Theme.of(context).textTheme.headlineSmall,
                      ),
                      const SizedBox(height: 8),
                      Text(_status, textAlign: TextAlign.center),
                      const SizedBox(height: 16),
                      if (_monitoring) ...[
                        LinearProgressIndicator(value: levelFraction),
                        const SizedBox(height: 4),
                        Text('${_currentDb.toStringAsFixed(0)} dBFS',
                            style: Theme.of(context).textTheme.bodySmall),
                        const SizedBox(height: 12),
                      ],
                      FilledButton.icon(
                        onPressed: _monitoring ? _stopMonitoring : _startMonitoring,
                        icon: Icon(_monitoring ? Icons.stop : Icons.play_arrow),
                        label: Text(_monitoring
                            ? tr('To‘xtatish', 'Остановить', 'Stop')
                            : tr('Kuzatuvni boshlash', 'Начать мониторинг', 'Start monitoring')),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(tr('Tungi statistika', 'Ночная статистика', 'Night summary'),
                          style: Theme.of(context).textTheme.titleLarge),
                      const SizedBox(height: 12),
                      _metric(tr('Aniqlangan hodisalar', 'Обнаруженные события', 'Detected events'),
                          '$_events'),
                      _metric(tr('Kuzatuv vaqti', 'Время мониторинга', 'Monitoring time'),
                          _elapsedText()),
                      const SizedBox(height: 12),
                      SwitchListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(tr('Signal yoqilgan', 'Оповещение включено', 'Alerts enabled')),
                        subtitle: Text(tr('Vibratsiya va ovoz', 'Вибрация и звук', 'Vibration and sound')),
                        value: _alertEnabled,
                        onChanged: (value) => setState(() => _alertEnabled = value),
                      ),
                      const SizedBox(height: 8),
                      Text(tr(
                          'Sezgirlik chegarasi (demo)',
                          'Порог чувствительности (демо)',
                          'Sensitivity threshold (demo)')),
                      Slider(
                        min: -45,
                        max: -10,
                        divisions: 35,
                        value: _thresholdDb,
                        label: '${_thresholdDb.toStringAsFixed(0)} dBFS',
                        onChanged: (value) => setState(() => _thresholdDb = value),
                      ),
                      Text(
                        tr(
                          'Eslatma: bu prototip balandlik chegarasini tekshiradi, xurrakni ishonchli tasniflamaydi.',
                          'Важно: прототип реагирует на громкость и не распознаёт храп надёжно.',
                          'Note: this prototype checks loudness; it does not reliably classify snoring.',
                        ),
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _metric(String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Expanded(child: Text(label)),
            Text(value, style: const TextStyle(fontWeight: FontWeight.bold)),
          ],
        ),
      );
}
