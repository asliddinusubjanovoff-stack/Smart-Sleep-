# Smart Sleep Monitor — Flutter prototype

UZ/RU/EN interfeys, mikrofon oqimidan real vaqtda balandlik (dBFS) hisoblash,
chegaradan oshganda vibratsiya + signal, hodisalar soni va kuzatuv vaqti.

## Ishga tushirish (birinchi marta)

Loyiha papkasida (pubspec.yaml turgan joyda):

```bash
flutter create --platforms=android,ios .
dart run tool/setup.dart
flutter pub get
flutter run
```

- `tool/setup.dart` Android ruxsatlarini (mikrofon, vibratsiya, wakelock),
  `minSdk = 23` va iOS mikrofon izohini avtomatik qo'shadi.
- Eng yaxshisi: USB orqali ulangan **haqiqiy Android telefon**
  (Sozlamalar → Telefon haqida → Build number 7 marta → USB debugging).
- Keyingi safar faqat `flutter run` yetarli.

## Tun bo'yi sinash
Telefonni zaryadga ulang. Ilova ishlayotganda ekran o'chmaydi (wakelock).
To'liq fon rejimi uchun foreground service kerak (hozircha yo'q).

## Muhim cheklov
Bu prototip faqat **balandlik**ni o'lchaydi, xurrakni aniqlamaydi (eshik, nutq,
ventilyator ham ishga tushadi). Tibbiy tashxis uchun ishlatmang.
Haqiqiy aniqlash uchun belgilangan audio ma'lumot va TFLite modeli kerak.
Xom audio saqlanmaydi.
